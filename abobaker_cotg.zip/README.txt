Open THIS folder in Code on the Go: abobaker_cotg
Do not select the ZIP file and do not select the app folder.
